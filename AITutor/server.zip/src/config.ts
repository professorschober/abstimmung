import dotenv from "dotenv";
import { z } from "zod";

dotenv.config();

const configSchema = z.object({
  PORT: z.coerce.number().int().positive().default(3001),
  CLIENT_ORIGINS: z.string().default("http://localhost:5173"),
  OPENAI_API_KEY: z.string().trim().min(1).optional(),
  OPENAI_MODEL: z.string().min(1).default("gpt-4.1-mini"),
  MAX_INPUT_CHARS: z.coerce.number().int().positive().default(1500),
});

const rawConfig = configSchema.parse(process.env);
const parsedOrigins = rawConfig.CLIENT_ORIGINS.split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

parsedOrigins.forEach((origin) => z.string().url().parse(origin));

export const config = {
  ...rawConfig,
  CLIENT_ORIGINS: parsedOrigins,
};

export function hasOpenAIKey(): boolean {
  return Boolean(config.OPENAI_API_KEY && config.OPENAI_API_KEY !== "your_openai_api_key_here");
}
